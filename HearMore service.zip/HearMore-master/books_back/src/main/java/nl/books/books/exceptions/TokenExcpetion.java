package nl.books.books.exceptions;

public class TokenExcpetion extends RuntimeException {
    public TokenExcpetion(String message) {
        super(message);
    }
}
